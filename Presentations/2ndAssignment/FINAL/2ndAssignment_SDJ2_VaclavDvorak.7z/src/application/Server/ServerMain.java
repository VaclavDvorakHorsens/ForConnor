package application.Server;

import java.rmi.AlreadyBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

import application.Server.ServerRemoteObjects.BoundedQueue;
import application.Server.ServerRemoteObjects.RemoteServerBounderQueue;

public class ServerMain
{

   public static void main(String[] args) throws RemoteException, AlreadyBoundException
   {
      
      //create registry and add RemoteServerBounderQueue object in it
      Registry registry =LocateRegistry.createRegistry(1099);
      RemoteServerBounderQueue remoteServerObject=new BoundedQueue();
      registry.bind("remoteObject",remoteServerObject);
      System.out.println("Server is running");

   }

}

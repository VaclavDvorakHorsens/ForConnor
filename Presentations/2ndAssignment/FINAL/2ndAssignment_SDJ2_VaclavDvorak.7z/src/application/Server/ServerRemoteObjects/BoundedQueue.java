package application.Server.ServerRemoteObjects;

import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.LinkedList;
import java.util.Queue;

import application.BurgerAndHisArrayList.ArrayList;
import application.BurgerAndHisArrayList.Burger;
import application.BurgerAndHisArrayList.ListADT;
import application.Clients.BurgerBarManager.BurgerBarManager;
import application.Clients.Chef.Chef;
import application.Clients.Chef.ChefClientInterface;
import application.Clients.Guest.Guest;
import application.Clients.Guest.GuestInterface;

public class BoundedQueue<T> implements RemoteServerBounderQueue 
{

 private BurgerBarManager burgerBarManager;  
 private ArrayList<GuestInterface> listOfGuests;  
 private ArrayList<ChefClientInterface> listOfChefs;
 private ListADT listOfBurgers;
 private boolean isListOfBurgersFull;


 
 //export THIS, set listOfGuests,listOfChefs,listOfBurgers
 public BoundedQueue() throws RemoteException
 {
    UnicastRemoteObject.exportObject(this,0);
    listOfGuests=new ArrayList<GuestInterface>();
    listOfChefs=new ArrayList<ChefClientInterface>();
    listOfBurgers=new ArrayList<T>(); 
    isListOfBurgersFull=false;
 }
 

//keeps adding burgers to list until its full
@Override
public synchronized void addBurger(Object element) throws RemoteException
{   
   while(isListOfBurgersFull==true)
   {
      try {
            wait();
          }
      catch(InterruptedException e)
      {
         e.printStackTrace();
      }
 
   }
   listOfBurgers.add((T) element);
   System.out.println("new burger has been cooked, size of listOfBurges is now:"+listOfBurgers.size());
   
 //maximum limit of cooked and not eaten burgers is set on 100
   if(listOfBurgers.size()>100)
   {
      isListOfBurgersFull=listOfBurgers.isFull();
   }
   
   notifyAll(); 
}




//receives index 0, so it simulates dequeue, guest is
//getting a burger from listOfBurgers and removing it from listOfBurgers

@Override
public synchronized Object getBurger(int index) throws RemoteException
{
   while(listOfBurgers.isEmpty()==true || index>listOfBurgers.size()-1)
   {
      try {
            wait();
          }
      catch(InterruptedException e)
      {
         e.printStackTrace();
      }
   } 
   notifyAll();
   
   
   if(listOfBurgers.size()<=100)
   {
      isListOfBurgersFull=false;
   }
   
   System.out.println("guest wants a burger and takes it from listOfBurgers");
   return listOfBurgers.remove(index); 
}




//receives person(either GuestInterface instance, BrugerBarManager
//instance or ChefClientInterface instance and saves in list)
@Override
public void addClientToServerList(Object person) throws RemoteException
{
   if(person instanceof GuestInterface)
   {
 
      listOfGuests.add((GuestInterface) person);

   }
   if(person instanceof BurgerBarManager)
   {
      this.burgerBarManager=(BurgerBarManager) person; 

   }
   if(person instanceof ChefClientInterface)
   {
      listOfChefs.add((ChefClientInterface) person); 
   
   }
   
}


//calls every Guest and Chef and Manager via their interfaces stops them from
//producing/eating burgers (stops their threads)+closes Manager's GUI
@Override
public void shutDownTheBar() throws RemoteException
{
  
   for(int i=0;i<listOfGuests.size();i++)
   {
     
      try
      {
         listOfGuests.get(i).DisconnectFromServer();
      }
      catch (InvocationTargetException e)
      {
         e.printStackTrace();
      }
   }
   for(int i=0;i<listOfChefs.size();i++)
   { 
      try
      {
         listOfChefs.get(i).DisconnectFromServer();
      }
      catch (InvocationTargetException e)
      {
    
         e.printStackTrace();
      }
   }
   burgerBarManager=null;
   
}




}

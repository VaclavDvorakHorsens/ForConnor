package application.Server.ServerRemoteObjects;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface RemoteServerBounderQueue extends Remote
{

   void addBurger(Object element) throws RemoteException;
   Object getBurger(int index) throws RemoteException;
   void addClientToServerList(Object person) throws RemoteException;
   void shutDownTheBar() throws RemoteException;
   
}

package application.testing;

import static org.junit.Assert.*;

import java.util.ArrayList;
import org.junit.Before;
import org.junit.Test;

import application.BurgerAndHisArrayList.Burger;

public class Test_ArrayList
{


   Burger burger;
   ArrayList<Burger> listOfBurgers;
   int size;
   
   @Before
   public void setup()
   {
     this.listOfBurgers = new ArrayList<Burger>();
     this.burger=new Burger("novyBurger");
    
   }
   
  
   
 //EXAMPLE OF TESTING BOUNDARIES and PARTITIONING ON METHOD ADD()
      //adding 1st burger
   @Test
   public void testBoundaries_minIndex()
   {
      setup();
      listOfBurgers.add(0, (Burger) burger);
      assertTrue(listOfBurgers.get(0).equals(burger));
       assertEquals(listOfBurgers.size(),1);
   }
   
  
   
      //adding last burger before T[] doubles capacity 
   @Test 
   public void testBoundaries_maxIndexBeforeExpandCapacity()
   {
      setup();
      for(int i=0;i<99;i++)
      {
         listOfBurgers.add(i,(Burger) burger);
      }
      assertTrue(listOfBurgers.get(0).equals(burger));
      assertTrue(listOfBurgers.get(98).equals(burger));
      assertEquals(listOfBurgers.size(),99);
   }
   
   
   
      //adding 1st burger after T[] doubles capacity 
   @Test 
   public void testBoundaries_expandCapacity()
   {
      setup();
      for(int i=0;i<101;i++)
      {
         listOfBurgers.add(i,(Burger) burger);
      }
     
      assertTrue(listOfBurgers.get(100).equals(burger));
  
   }
  
   
   

   //EXAMPLE OF TESTING BRANCHES ON METHOD ADD()
   @Test (expected = IndexOutOfBoundsException.class)
   public void testBranch_IndexOutOfBoundsException_IndexHigherThanSize()
   {
      setup();
      listOfBurgers.add(1, (Burger) burger);
      fail("cannot add index 1 when size still 0");
   }
   
   @Test (expected = IndexOutOfBoundsException.class)
   public void testBranch_IndexOutOfBoundsException_IndexLowerThanSize()
   {
      setup();
      listOfBurgers.add(-1, (Burger) burger);
      fail("cannot add index lower than 0");
   }
   

}